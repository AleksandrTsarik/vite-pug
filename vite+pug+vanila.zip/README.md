src/
├── pages/
│ ├── index.pug
│ └── about.pug
├── components/
│ ├── \_header.pug
│ ├── \_footer.pug
│ └── \_mixin.pug
│ └── \_scripts.pug
├── layouts/
│ └── default.pug
└── assets/
├── scss/main.scss
└── js/main.js
